import identicon
img= identicon.render_identicon('123123', 16)
img.show()